<?php

namespace Ais;
use Exception;
use Ais\Helper\Helper;

error_reporting(E_ALL);

// Schreibprozess (Daten sammeln und in Redis schreiben):
class DataFetcher {
    private $ip;
    private $port;

    public function __construct($ip, $port) {
        $this->ip = $ip;
        $this->port = $port;
    }

    public function connect(){

        $sock = fsockopen($this->ip,$this->port, $errno, $errstr, 5);

        if (!$sock){
            throw new Exception("fsockopen() failed: error_code: $errno, error_message: $errstr");
        }



//        $errno = "";
//        $errstr = "";
//        $sock = fsockopen($this->ip, $this->port,$errno, $errstr,5);
//        if ($sock === false) {
//            throw new Exception("socket_create() failed: reason: " . socket_strerror(socket_last_error()));
//        }
        return $sock;
    }




    public function fetchAndSendToRedis() {

        $sock = $this->connect();
        $data = [];
        $startTime = time();
        $endTime = $startTime + 50;
        $readTimeout = 300;
        $decodedDataA = [];


        stream_set_timeout($sock, $readTimeout);

        $info = stream_get_meta_data($sock);
        if ($info['timed_out']) {
            trigger_error('Timeout');
        }

        while (time() < $endTime) {

            $buffer = fread($sock,1024);

            if (!$buffer) {
                if (feof($sock)) {
                    echo "Verbindung geschlossen." . '<br>';
                } else {
                    echo "Fehler beim Lesen vom Socket." . '<br>';
                }
                break;
            }

            if (empty($buffer)) {
                echo "Verbindung geschlossen" . '<br>';
                break;
            }
            else {
                $data = explode("\n", $buffer);
            }

            echo "<pre>";
            echo "Empfangene Daten: " . $buffer . PHP_EOL;

            $decodedData = $this->sendDataToDecoder($data);
            if(!empty($decodedData)) {
                $decodedDataA[$decodedData->mmsi] = $decodedData;
            }
        }

        fclose($sock);
        $redis = new RedisData();
        $redis->connect();
        $redis->clear();
        $redis->write($decodedDataA);
        $test = $redis->read();
        $redis->close();

    }


//    public function writeDataToRedis($decodedData)
//    {
//
//        //serialisierung
//        $redis = new \Redis();
//        $redis->connect('127.0.0.1', 6379);
////        echo "Verbindung zum Server erfolgreich hergestellt." . PHP_EOL;
//        $redis->del('ais_data');
//        $redis->rpush('ais_data', serialize($decodedData));
//        $redis->close();
//    }

    function sendDataToDecoder(array $data)
    {
        $decodedData = null;
        $helper = new Helper();

        foreach ($data as $line){

            if (empty($line)) {
                continue;
            }

            $helper->process_ais_buf($line);
            $decodedData = $helper->_resultBuffer;
            //var_dump($decodedData);
        }
        return $decodedData;
    }

}

?>
